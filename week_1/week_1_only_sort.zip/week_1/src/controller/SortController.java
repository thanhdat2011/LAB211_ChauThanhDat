/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import model.Util;
import model.BubbleSort;
import model.QuickSort;

/**
 *
 * @author PC
 */
public class SortController {

    private final static Util util = new Util();
    private final static QuickSort quickSort = new QuickSort();
    private final static BubbleSort bubbleSort = new BubbleSort();
    
    public void quickSort(){
        int size = Integer.parseInt(util.getInput("Enter number of array"));
        int[] arr = util.generateRandomArray(size);
        util.displayArray("Unsorted array", arr);
        quickSort.doQuickSort(arr, 0, size-1);
        util.displayArray("Sorted Array", arr);
              
    }

    public void bubbleSort() {
        int size = Integer.parseInt(util.getInput("Enter number of array"));
        int[] arr = util.generateRandomArray(size);
        util.displayArray("Unsorted array", arr);
        bubbleSort.doBubbleSort(arr);
        util.displayArray("Sorted array", arr);
    }
    
}
